#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/SListView.h"
#include "UObject/StrongObjectPtr.h"
#include "Materials/MaterialInterface.h"
#include "AssetData.h"
#include "ContentBrowserDelegates.h"
#include "Misc/TextFilter.h"

struct FMaterialInfoRow
{
    FString Name, Group, Kind, Value, Origin, Source;
    bool bLocal = false, bColor = false;
    bool bValueValid = false, bSwitchValue = false;
    float ScalarValue = 0;
    FLinearColor Color = FLinearColor::White;
    class UTexture* Texture = nullptr;
};
TArray<TSharedPtr<FMaterialInfoRow>> ReadMaterialParameters(UMaterialInterface* Material);

class SMaterialInfoViewer : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SMaterialInfoViewer) {} SLATE_END_ARGS()
    void Construct(const FArguments& Args);
    virtual void Tick(const FGeometry& Geometry,double CurrentTime,float DeltaTime) override;
    void SelectAsset(const FAssetData& Asset);
private:
    friend class FMaterialInfoViewerTest;
    friend class FMaterialBlendFilterTest;
    TArray<TSharedPtr<FString>> BlendOptions;
    TArray<int32> BlendCounts = {0,0,0,0,0};
    TArray<FAssetData> BlendCountAssets;
    int32 BlendCountCursor = 0, BlendCountFailed = 0;
    bool bBlendCounting = false, bBlendCountPending = false;
    TWeakPtr<class SSearchBox> AssetNameSearch;
    FString CountSearchText;
    TSharedPtr<TTextFilter<const FAssetData&>> CountNameFilter;
    void RequestBlendCount();
    FText BlendLabel(int32 Index) const;
    FText BlendSummary() const;
    bool bAllBlendModes = true;
    uint8 BlendMask = 0;
    FRefreshAssetViewDelegate RefreshAssetView;
    TSharedPtr<SWidget> AssetPicker;
    void ApplyBlendSelection(uint8 Mask,bool bAll);
    void SetBlendChecked(int32 Index,ECheckBoxState State);
    bool ShouldFilterMaterial(const FAssetData& Asset) const;
    TStrongObjectPtr<UMaterialInterface> Selected;
    TArray<TSharedPtr<FMaterialInfoRow>> AllRows, Rows;
    TSharedPtr<class SVerticalBox> ParameterGroups;
    TMap<FString,bool> ExpansionState;
    TMap<FString,TSharedPtr<class SExpandableArea>> GroupAreas;
    TSharedPtr<class SVerticalBox> Details;
    TSharedPtr<class SMaterialInfoPreview> Preview;
    TSharedPtr<class SSplitter> PreviewSplitter;
    TSharedPtr<class FAssetThumbnailPool> ThumbnailPool;
    FString Filter;
    bool bLocalOnly = false;
    void FilterRows();
    void Refresh();
    void RebuildParameterGroups();
    TSharedRef<SWidget> ParameterRow(TSharedPtr<FMaterialInfoRow> Row);
};
