#include "MaterialInfoViewer.h"
#include "MaterialInfoPreview.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstance.h"
#include "StaticParameterSet.h"
#include "Engine/Texture.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "Editor.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "Widgets/Layout/SSplitter.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Input/SSpinBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Colors/SColorBlock.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Views/STableRow.h"
#include "EditorStyleSet.h"
#include "AssetThumbnail.h"
#include "Misc/PackageName.h"
#include "AssetRegistryModule.h"

namespace
{
FText Txt(const FString& S) { return FText::FromString(S); }
bool HasLocal(UMaterialInstance* Instance,const FMaterialParameterInfo& Info,int32 Kind)
{
    if(Kind==0) return Instance->ScalarParameterValues.ContainsByPredicate([&](const FScalarParameterValue& P){return P.ParameterInfo==Info;});
    if(Kind==1) return Instance->VectorParameterValues.ContainsByPredicate([&](const FVectorParameterValue& P){return P.ParameterInfo==Info;});
    if(Kind==2) return Instance->TextureParameterValues.ContainsByPredicate([&](const FTextureParameterValue& P){return P.ParameterInfo==Info;});
    if(Kind==3) return Instance->GetStaticParameters().StaticSwitchParameters.ContainsByPredicate([&](const FStaticSwitchParameter& P){return P.ParameterInfo==Info && P.bOverride;});
    return Instance->GetStaticParameters().StaticComponentMaskParameters.ContainsByPredicate([&](const FStaticComponentMaskParameter& P){return P.ParameterInfo==Info && P.bOverride;});
}
void FindOrigin(UMaterialInterface* Material,const FMaterialParameterInfo& Info,int32 Kind,FMaterialInfoRow& Row)
{
    // Layer defaults can be supplied by instance-local cached layer graphs rather than Parent.
    // Do not attribute those defaults to the base material without resolving the layer graph.
    auto SelectedInstance=Cast<UMaterialInstance>(Material);
    if(SelectedInstance && Info.Association!=EMaterialParameterAssociation::GlobalParameter && !HasLocal(SelectedInstance,Info,Kind))
    {
        Row.Origin=TEXT("상속 / 레이어 기본값 · 상세 출처는 원본에서 확인");
        return;
    }
    TSet<UMaterialInterface*> Seen;
    for(UMaterialInterface* Current=Material; Current && !Seen.Contains(Current);)
    {
        Seen.Add(Current);
        auto Instance=Cast<UMaterialInstance>(Current);
        if(!Instance || HasLocal(Instance,Info,Kind))
        {
            Row.bLocal=Instance && Current==Material;
            Row.Origin=Row.bLocal ? TEXT("직접 변경") : (Current==Material ? TEXT("머티리얼 기본값") : TEXT("부모 상속"));
            Row.Source=Current->GetPathName(); return;
        }
        Current=Instance->Parent;
    }
    Row.Origin=TEXT("출처 확인 불가");
}
FString PropertyOrigin(UMaterialInterface* Material,int32 Kind)
{
    TSet<UMaterialInterface*> Seen;
    for(UMaterialInterface* Current=Material;Current && !Seen.Contains(Current);)
    {
        Seen.Add(Current);
        auto Instance=Cast<UMaterialInstance>(Current);
        bool bOverride=false;
        if(Instance) {
            const auto& O=Instance->BasePropertyOverrides;
            bOverride=Kind==0 ? O.bOverride_BlendMode : Kind==1 ? O.bOverride_ShadingModel : Kind==2 ? O.bOverride_TwoSided : O.bOverride_OpacityMaskClipValue;
        }
        if(!Instance || bOverride)
            return FString(Current==Material ? (Instance ? TEXT("직접 변경 · ") : TEXT("기본값 · ")) : TEXT("부모 상속 · "))+Current->GetName();
        Current=Instance->Parent;
    }
    return TEXT("출처 확인 불가");
}
}

TArray<TSharedPtr<FMaterialInfoRow>> ReadMaterialParameters(UMaterialInterface* Material)
{
    TArray<TSharedPtr<FMaterialInfoRow>> Result;
    if(!Material) return Result;
    for(int32 Kind=0;Kind<5;++Kind)
    {
        TArray<FMaterialParameterInfo> Infos; TArray<FGuid> Ids;
        if(Kind==0) Material->GetAllScalarParameterInfo(Infos,Ids);
        if(Kind==1) Material->GetAllVectorParameterInfo(Infos,Ids);
        if(Kind==2) Material->GetAllTextureParameterInfo(Infos,Ids);
        if(Kind==3) Material->GetAllStaticSwitchParameterInfo(Infos,Ids);
        if(Kind==4) Material->GetAllStaticComponentMaskParameterInfo(Infos,Ids);
        for(const auto& Info:Infos)
        {
            auto Row=MakeShared<FMaterialInfoRow>();
            Row->Name=Info.Name.ToString();
            if(Info.Association!=EMaterialParameterAssociation::GlobalParameter)
                Row->Name+=FString::Printf(TEXT(" [Layer/Blend %d:%d]"),int32(Info.Association),Info.Index);
            FName Group; Material->GetGroupName(Info,Group);
            Row->Group=Group.IsNone() ? TEXT("기본 그룹") : Group.ToString();
            bool bFound=false;
            if(Kind==0) { bFound=Material->GetScalarParameterValue(Info,Row->ScalarValue); Row->Kind=TEXT("Scalar"); Row->Value=FString::SanitizeFloat(Row->ScalarValue); }
            if(Kind==1) { bFound=Material->GetVectorParameterValue(Info,Row->Color); Row->Kind=TEXT("Vector / Color"); Row->bColor=true; Row->Value=FString::Printf(TEXT("R %.4g  G %.4g  B %.4g  A %.4g"),Row->Color.R,Row->Color.G,Row->Color.B,Row->Color.A); }
            if(Kind==2) { bFound=Material->GetTextureParameterValue(Info,Row->Texture); Row->Kind=TEXT("Texture"); Row->Value=Row->Texture ? Row->Texture->GetPathName() : TEXT("없음"); }
            if(Kind==3) { FGuid Id; bFound=Material->GetStaticSwitchParameterValue(Info,Row->bSwitchValue,Id); Row->Kind=TEXT("Static Switch"); Row->Value=Row->bSwitchValue ? TEXT("True") : TEXT("False"); }
            if(Kind==4) { bool R=false,G=false,B=false,A=false; FGuid Id; bFound=Material->GetStaticComponentMaskParameterValue(Info,R,G,B,A,Id); Row->Kind=TEXT("Static Mask"); Row->Value=FString::Printf(TEXT("R %d  G %d  B %d  A %d"),R,G,B,A); }
            Row->bValueValid=bFound;
            if(!bFound) Row->Value=TEXT("현재 값 조회 불가");
            FindOrigin(Material,Info,Kind,*Row);
            Result.Add(Row);
        }
    }
    Result.Sort([](const TSharedPtr<FMaterialInfoRow>& A,const TSharedPtr<FMaterialInfoRow>& B){
        if(A->Group!=B->Group) return A->Group<B->Group;
        if(A->Kind!=B->Kind) return A->Kind<B->Kind;
        return A->Name<B->Name;
    });
    return Result;
}

void SMaterialInfoViewer::Construct(const FArguments& Args)
{
    ThumbnailPool=MakeShared<FAssetThumbnailPool>(32);
    for(const TCHAR* Choice:{TEXT("전체"),TEXT("Opaque"),TEXT("Masked"),TEXT("Translucent"),TEXT("Additive")}) BlendOptions.Add(MakeShared<FString>(Choice));
    FAssetPickerConfig Picker;
    Picker.Filter.ClassNames.Add(UMaterialInterface::StaticClass()->GetFName());
    Picker.Filter.bRecursiveClasses=true;
    Picker.Filter.PackagePaths.Add(TEXT("/Game")); Picker.Filter.bRecursivePaths=true;
    Picker.SelectionMode=ESelectionMode::Single; Picker.InitialAssetViewType=EAssetViewType::List;
    Picker.OnAssetSelected=FOnAssetSelected::CreateLambda([WeakViewer=TWeakPtr<SMaterialInfoViewer>(SharedThis(this))](const FAssetData& Asset){
        // Source refresh and GC can emit an empty selection; keep the last inspected asset.
        if(Asset.IsValid()) if(auto Viewer=WeakViewer.Pin())
            if(!Viewer->ShouldFilterMaterial(Asset)) Viewer->SelectAsset(Asset);
    });
    Picker.OnShouldFilterAsset=FOnShouldFilterAsset::CreateSP(this,&SMaterialInfoViewer::ShouldFilterMaterial);
    Picker.RefreshAssetViewDelegates.Add(&RefreshAssetView);
    auto& Browser=FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser"));
    AssetPicker=Browser.Get().CreateAssetPicker(Picker);
    CountNameFilter=MakeShared<TTextFilter<const FAssetData&>>(TTextFilter<const FAssetData&>::FItemToStringArray::CreateLambda([](const FAssetData& Asset,TArray<FString>& Strings){Strings.Add(Asset.AssetName.ToString());}));
    TFunction<void(const TSharedRef<SWidget>&)> FindNameSearch=[this,&FindNameSearch](const TSharedRef<SWidget>& Widget){
        if(Widget->GetTypeAsString()==TEXT("SSearchBox") && !AssetNameSearch.IsValid()) AssetNameSearch=StaticCastSharedRef<SSearchBox>(Widget);
        auto Children=Widget->GetChildren();for(int32 I=0;I<Children->Num();++I) FindNameSearch(Children->GetChildAt(I));
    };
    FindNameSearch(AssetPicker.ToSharedRef());
    auto BlendChecks=SNew(SWrapBox).UseAllottedWidth(true).InnerSlotPadding(FVector2D(8,3));
    for(int32 Index=0;Index<5;++Index) BlendChecks->AddSlot()[SNew(SCheckBox)
        .IsChecked_Lambda([this,Index]{return (Index==0?bAllBlendModes:!bAllBlendModes && (BlendMask & (1<<(Index-1))))?ECheckBoxState::Checked:ECheckBoxState::Unchecked;})
        .OnCheckStateChanged_Lambda([this,Index](ECheckBoxState State){SetBlendChecked(Index,State);})
        [SNew(STextBlock).Text_Lambda([this,Index]{return BlendLabel(Index);})]];
    ChildSlot[SNew(SBorder).BorderImage(FEditorStyle::GetBrush("ToolPanel.GroupBorder")).Padding(12)
    [SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight().Padding(0,0,0,8)[SNew(STextBlock).Text(Txt(TEXT("Material Info Viewer — 머티리얼 정보 · 조회 전용"))) ]
        + SVerticalBox::Slot().FillHeight(1)
        [SNew(SSplitter)
            + SSplitter::Slot().Value(.27f)[SNew(SVerticalBox)
                + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(Txt(TEXT("1. 머티리얼 / 인스턴스 검색 · 선택")))]
                + SVerticalBox::Slot().AutoHeight().Padding(0,5)[SNew(SVerticalBox)
                    + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(Txt(TEXT("Blend Mode · 여러 종류 선택 가능")))]
                    + SVerticalBox::Slot().AutoHeight().Padding(0,3)[BlendChecks]]
                + SVerticalBox::Slot().AutoHeight().Padding(0,0,0,3)[SNew(STextBlock).AutoWrapText(true).Text_Lambda([this]{return BlendSummary();})
                    .ToolTipText(Txt(TEXT("현재 이름 검색에 해당하는 Material과 Material Instance를 최종 Blend Mode별로 집계합니다. Blend Mode 선택과 관계없이 각 종류의 개수가 표시되며 검색어를 지우면 프로젝트 전체 개수로 돌아갑니다."))) ]
                + SVerticalBox::Slot().FillHeight(1).Padding(0,6)[AssetPicker.ToSharedRef()]]
            + SSplitter::Slot().Value(.73f)
        [SAssignNew(PreviewSplitter,SSplitter).Orientation(Orient_Vertical).PhysicalSplitterHandleSize(8).HitDetectionSplitterHandleSize(12).MinimumSlotHeight(140)
            + SSplitter::Slot().Value(.62f)
        [SNew(SSplitter)
            + SSplitter::Slot().Value(.60f)[SNew(SVerticalBox)
                + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text_Lambda([this]{return Txt(FString::Printf(TEXT("2. 파라미터 · 현재 적용값 (%d / %d)"),Rows.Num(),AllRows.Num()));})]
                + SVerticalBox::Slot().AutoHeight().Padding(6)[SNew(SSearchBox).HintText(Txt(TEXT("이름 / 그룹 / 종류 / 값 / 출처 검색"))).OnTextChanged_Lambda([this](const FText& Value){Filter=Value.ToString();FilterRows();})]
                + SVerticalBox::Slot().AutoHeight().Padding(6,0)[SNew(SCheckBox).OnCheckStateChanged_Lambda([this](ECheckBoxState Value){bLocalOnly=Value==ECheckBoxState::Checked;FilterRows();})[SNew(STextBlock).Text(Txt(TEXT("선택한 인스턴스에서 직접 변경한 값만")))]]
                + SVerticalBox::Slot().FillHeight(1).Padding(6)[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(ParameterGroups,SVerticalBox)]]
                + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text_Lambda([this]{return Txt(!Selected.IsValid()?TEXT("왼쪽에서 머티리얼을 선택하세요."):AllRows.Num()==0?TEXT("노출된 파라미터가 없습니다. 고정 상수·연결 구조는 원본 그래프에서 확인하세요."):Rows.Num()==0?TEXT("검색 조건에 맞는 파라미터가 없습니다."):TEXT("직접 변경 = 이 인스턴스의 Override / 부모 상속 = 상위 인스턴스 또는 기본 머티리얼의 값"));})]]
            + SSplitter::Slot().Value(.40f)[SNew(SVerticalBox)
                + SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(Txt(TEXT("3. 기본 정보 · 부모와 실제 적용 설정")))]
                + SVerticalBox::Slot().FillHeight(1).Padding(6)[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(Details,SVerticalBox)]]]]
            + SSplitter::Slot().Value(.38f)[SNew(SVerticalBox)
        + SVerticalBox::Slot().AutoHeight().Padding(0,8)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().FillWidth(1)[SNew(STextBlock).Text(Txt(TEXT("실시간 미리보기 · 위 경계 드래그로 크기 조절")))]
            + SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text_Lambda([this]{return Txt(Preview->IsPlane()?TEXT("구로 보기"):TEXT("평면으로 보기"));}).OnClicked_Lambda([this]{Preview->ToggleShape();return FReply::Handled();})]
            + SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SButton).Text_Lambda([this]{return Txt(Preview->IsPaused()?TEXT("계속 재생"):TEXT("일시정지"));}).OnClicked_Lambda([this]{Preview->TogglePause();return FReply::Handled();})]
            + SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SButton).Text(Txt(TEXT("시점 초기화"))).OnClicked_Lambda([this]{Preview->ResetCamera();return FReply::Handled();})]
            + SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(Txt(TEXT("정보 새로고침"))).OnClicked_Lambda([this]{
                if(Selected.IsValid() && ShouldFilterMaterial(FAssetData(Selected.Get()))) SelectAsset(FAssetData());else Refresh();
                RequestBlendCount();RefreshAssetView.ExecuteIfBound(true);return FReply::Handled();})]
            + SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SButton).Text(Txt(TEXT("원본 에디터 열기"))).IsEnabled_Lambda([this]{return Selected.IsValid();}).OnClicked_Lambda([this]{if(GEditor && Selected.IsValid()) GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Selected.Get());return FReply::Handled();})]]
        + SVerticalBox::Slot().FillHeight(1)[SAssignNew(Preview,SMaterialInfoPreview)]
        + SVerticalBox::Slot().AutoHeight().Padding(0,4)[SNew(STextBlock).Text(Txt(TEXT("왼쪽 드래그: 회전 · 휠: 확대/축소 · 오른쪽 세로 드래그: 확대/축소 · F: 시점 초기화")))]
        + SVerticalBox::Slot().AutoHeight().Padding(0,6)[SNew(STextBlock).AutoWrapText(true).Text(Txt(TEXT("조회 전용 · 값 변경과 저장 없음. 미리보기는 구/평면 표면에 표시하며 실제 파티클·메시·장면에서의 모습은 사용 환경에 따라 다릅니다.")))]]]]
    ]];
    Preview->SetMaterial(nullptr);
    RequestBlendCount();
}
void SMaterialInfoViewer::RequestBlendCount()
{
    bBlendCountPending=true;bBlendCounting=true;BlendCountAssets.Empty();BlendCountCursor=0;BlendCountFailed=0;
    for(int32& Count:BlendCounts) Count=0;
}
FText SMaterialInfoViewer::BlendLabel(int32 Index) const
{
    if(!BlendOptions.IsValidIndex(Index)) return FText::GetEmpty();
    return Txt(*BlendOptions[Index]+(bBlendCounting?TEXT(" (집계 중…)"):FString::Printf(TEXT(" (%d개)"),BlendCounts[Index])));
}
FText SMaterialInfoViewer::BlendSummary() const
{
    if(bBlendCounting) return Txt(CountSearchText.IsEmpty()?TEXT("종류별 개수 집계 중…"):TEXT("검색 결과 개수 집계 중…"));
    FString Summary=CountSearchText.IsEmpty()?TEXT("전체 · "):TEXT("검색 결과 · ");
    for(int32 Index=1;Index<5;++Index) {if(Index>1) Summary+=TEXT(" · ");Summary+=FString::Printf(TEXT("%s %d"),**BlendOptions[Index],BlendCounts[Index]);}
    const int32 Other=BlendCounts[0]-BlendCounts[1]-BlendCounts[2]-BlendCounts[3]-BlendCounts[4]-BlendCountFailed;
    if(Other>0) Summary+=FString::Printf(TEXT(" · 기타 %d"),Other);
    if(BlendCountFailed) Summary+=FString::Printf(TEXT(" · 조회 불가 %d"),BlendCountFailed);
    return Txt(Summary);
}
void SMaterialInfoViewer::Tick(const FGeometry& Geometry,double CurrentTime,float DeltaTime)
{
    SCompoundWidget::Tick(Geometry,CurrentTime,DeltaTime);
    if(auto Search=AssetNameSearch.Pin()) {
        const FString Text=Search->GetText().ToString();
        if(Text!=CountSearchText) {CountSearchText=Text;CountNameFilter->SetRawFilterText(FText::FromString(Text));RequestBlendCount();}
    }
    if(!bBlendCounting) return;
    if(bBlendCountPending) {
        auto& Registry=FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
        if(Registry.IsLoadingAssets()) return;
        FARFilter AssetFilter;AssetFilter.ClassNames.Add(UMaterialInterface::StaticClass()->GetFName());AssetFilter.bRecursiveClasses=true;
        AssetFilter.PackagePaths.Add(TEXT("/Game"));AssetFilter.bRecursivePaths=true;
        Registry.GetAssets(AssetFilter,BlendCountAssets);
        BlendCountAssets.RemoveAll([this](const FAssetData& Asset){return !CountNameFilter->PassesFilter(Asset);});
        BlendCounts[0]=BlendCountAssets.Num();bBlendCountPending=false;
    }
    // Work in short slices so material loading does not batch the entire project in one frame.
    const double Deadline=FPlatformTime::Seconds()+.008;
    const EBlendMode Modes[]={BLEND_Opaque,BLEND_Masked,BLEND_Translucent,BLEND_Additive};
    while(BlendCountCursor<BlendCountAssets.Num() && FPlatformTime::Seconds()<Deadline) {
        auto Material=Cast<UMaterialInterface>(BlendCountAssets[BlendCountCursor++].GetAsset());
        if(!Material) {++BlendCountFailed;continue;}
        for(int32 Index=0;Index<4;++Index) if(Material->GetBlendMode()==Modes[Index]) {++BlendCounts[Index+1];break;}
    }
    if(BlendCountCursor==BlendCountAssets.Num()) {bBlendCounting=false;BlendCountAssets.Empty();}
}
void SMaterialInfoViewer::SelectAsset(const FAssetData& Asset)
{
    Selected.Reset(Cast<UMaterialInterface>(Asset.GetAsset()));
    Refresh();
}
bool SMaterialInfoViewer::ShouldFilterMaterial(const FAssetData& Asset) const
{
    if(bAllBlendModes) return false;
    if(BlendMask==0) return true;
    const EBlendMode Modes[]={BLEND_Opaque,BLEND_Masked,BLEND_Translucent,BLEND_Additive};
    auto Material=Cast<UMaterialInterface>(Asset.GetAsset());
    if(Material) for(int32 Index=0;Index<4;++Index) if((BlendMask & (1<<Index)) && Material->GetBlendMode()==Modes[Index]) return false;
    return true;
}
void SMaterialInfoViewer::ApplyBlendSelection(uint8 Mask,bool bAll)
{
    Mask &= 15;
    if(bAll) Mask=0;
    if(BlendMask==Mask && bAllBlendModes==bAll) return;
    BlendMask=Mask;bAllBlendModes=bAll;
    if(Selected.IsValid() && ShouldFilterMaterial(FAssetData(Selected.Get()))) SelectAsset(FAssetData());
    // A full source refresh must re-run the custom filter on previously excluded assets.
    // The same picker keeps its existing search text and combines it with this filter.
    RefreshAssetView.ExecuteIfBound(true);
}
void SMaterialInfoViewer::SetBlendChecked(int32 Index,ECheckBoxState State)
{
    if(Index==0) {ApplyBlendSelection(0,State==ECheckBoxState::Checked);return;}
    if(Index<1 || Index>4) return;
    const uint8 Bit=1<<(Index-1);
    const uint8 Current=bAllBlendModes?0:BlendMask;
    ApplyBlendSelection(State==ECheckBoxState::Checked?(Current|Bit):(Current&~Bit),false);
}
void SMaterialInfoViewer::FilterRows()
{
    Rows.Empty();
    for(const auto& Row:AllRows)
        if((!bLocalOnly || Row->bLocal) && (Filter.IsEmpty() || (Row->Name+TEXT(" ")+Row->Group+TEXT(" ")+Row->Kind+TEXT(" ")+Row->Value+TEXT(" ")+Row->Origin+TEXT(" ")+Row->Source).Contains(Filter))) Rows.Add(Row);
    if(ParameterGroups.IsValid()) RebuildParameterGroups();
}
void SMaterialInfoViewer::Refresh()
{
    AllRows=ReadMaterialParameters(Selected.Get()); FilterRows();
    Preview->SetMaterial(Selected.Get()); Details->ClearChildren();
    if(!Selected.IsValid()) return;
    auto Material=Selected.Get();
    auto Instance=Cast<UMaterialInstance>(Material);
    auto DropDown=[](const FString& Value)->TSharedRef<SWidget>{return SNew(SComboButton).IsEnabled(false)
        .ButtonContent()[SNew(STextBlock).Text(Txt(Value)).AutoWrapText(true)];};
    auto Field=[](const FString& Name,const TSharedRef<SWidget>& Value,const FString& Origin,bool bOverride,bool bOverrideBox)->TSharedRef<SWidget>{
        auto Label=SNew(SHorizontalBox);
        if(bOverrideBox) Label->AddSlot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,5,0)
            [SNew(SCheckBox).IsEnabled(false).IsChecked(bOverride?ECheckBoxState::Checked:ECheckBoxState::Unchecked).ToolTipText(Txt(TEXT("현재 인스턴스의 Override 상태 · 조회 전용")))];
        Label->AddSlot().FillWidth(1).VAlign(VAlign_Center)[SNew(STextBlock).Text(Txt(Name)).AutoWrapText(true)];
        return SNew(SBorder).BorderImage(FEditorStyle::GetBrush("NoBorder")).Padding(FMargin(3,5))
            [SNew(SHorizontalBox)
                + SHorizontalBox::Slot().FillWidth(.4f).VAlign(VAlign_Center)[Label]
                + SHorizontalBox::Slot().FillWidth(.6f)[SNew(SVerticalBox)
                    + SVerticalBox::Slot().AutoHeight()[Value]
                    + SVerticalBox::Slot().AutoHeight().Padding(0,3,0,0)[SNew(STextBlock).Text(Txt(Origin)).AutoWrapText(true)
                        .ColorAndOpacity(bOverride?FLinearColor(1,.65f,.2f):FLinearColor(.4f,.8f,1)).ToolTipText(Txt(Origin))]]];
    };
    auto AssetValue=[this,&DropDown](UObject* Asset)->TSharedRef<SWidget>{
        auto Layout=SNew(SHorizontalBox);
        auto Thumbnail=MakeShared<FAssetThumbnail>(Asset?FAssetData(Asset):FAssetData(),64,64,ThumbnailPool);
        Layout->AddSlot().AutoWidth().Padding(0,0,5,0)[SNew(SBox).WidthOverride(64).HeightOverride(64)[Thumbnail->MakeThumbnailWidget()]];
        Layout->AddSlot().FillWidth(1).VAlign(VAlign_Center)[DropDown(Asset?Asset->GetName():TEXT("None"))];
        return SNew(SBox).ToolTipText(Txt(Asset?Asset->GetPathName():TEXT("없음")))[Layout];
    };
    auto AddSection=[this](const FString& Title,const TSharedRef<SWidget>& Body,bool bCollapsed){
        Details->AddSlot().AutoHeight().Padding(0,0,0,5)[SNew(SExpandableArea).AreaTitle(Txt(Title)).InitiallyCollapsed(bCollapsed)
            .BorderImage(FEditorStyle::GetBrush("ToolPanel.GroupBorder")).HeaderPadding(FMargin(4,5)).Padding(FMargin(3)).BodyContent()[Body]];
    };
    auto General=SNew(SVerticalBox);
    UPhysicalMaterial* Physical=Material->GetPhysicalMaterial();
    FString PhysicalOrigin=TEXT("엔진 기본값"); bool bLocalPhysical=false;
    TSet<UMaterialInterface*> PhysicalSeen;
    for(UMaterialInterface* Current=Material;Current && !PhysicalSeen.Contains(Current);) {
        PhysicalSeen.Add(Current);
        auto CurrentInstance=Cast<UMaterialInstance>(Current);
        auto CurrentBase=Cast<UMaterial>(Current);
        UPhysicalMaterial* Explicit=CurrentInstance?CurrentInstance->PhysMaterial:CurrentBase?CurrentBase->PhysMaterial:nullptr;
        if(Explicit) {
            bLocalPhysical=Current==Material;
            PhysicalOrigin=FString(Current==Material?TEXT("직접 변경 · "):TEXT("부모 상속 · "))+Current->GetName();break;
        }
        Current=CurrentInstance?CurrentInstance->Parent:nullptr;
    }
    General->AddSlot().AutoHeight()[Field(TEXT("Phys Material"),AssetValue(Physical),PhysicalOrigin,bLocalPhysical,false)];
    General->AddSlot().AutoHeight()[Field(TEXT("Parent"),AssetValue(Instance?Instance->Parent:nullptr),Instance && Instance->Parent?TEXT("직접 지정 · 바로 위 부모"):TEXT("기본 Material · 부모 없음"),Instance && Instance->Parent,false)];
    AddSection(TEXT("일반"),General,false);
    auto Properties=SNew(SVerticalBox);
    const auto* Overrides=Instance?&Instance->BasePropertyOverrides:nullptr;
    Properties->AddSlot().AutoHeight()[Field(TEXT("Opacity Mask Clip Value"),SNew(SSpinBox<float>).Value(Material->GetOpacityMaskClipValue()).IsEnabled(false),PropertyOrigin(Material,3),Overrides && Overrides->bOverride_OpacityMaskClipValue,Instance!=nullptr)];
    Properties->AddSlot().AutoHeight()[Field(TEXT("Blend Mode"),DropDown(UEnum::GetDisplayValueAsText(Material->GetBlendMode()).ToString()),PropertyOrigin(Material,0),Overrides && Overrides->bOverride_BlendMode,Instance!=nullptr)];
    FString Shading;
    for(int32 Index=0;Index<MSM_NUM;++Index) if(Material->GetShadingModels().HasShadingModel(static_cast<EMaterialShadingModel>(Index))) {
        if(!Shading.IsEmpty()) Shading+=TEXT(", "); Shading+=UEnum::GetDisplayValueAsText(static_cast<EMaterialShadingModel>(Index)).ToString();
    }
    Properties->AddSlot().AutoHeight()[Field(TEXT("Shading Model"),DropDown(Shading),PropertyOrigin(Material,1),Overrides && Overrides->bOverride_ShadingModel,Instance!=nullptr)];
    Properties->AddSlot().AutoHeight()[Field(TEXT("Two Sided"),SNew(SCheckBox).IsEnabled(false).IsChecked(Material->IsTwoSided()?ECheckBoxState::Checked:ECheckBoxState::Unchecked),PropertyOrigin(Material,2),Overrides && Overrides->bOverride_TwoSided,Instance!=nullptr)];
    AddSection(TEXT("머티리얼 프로퍼티 오버라이드"),Properties,false);
    auto Metadata=SNew(SVerticalBox);
    auto TextInfo=[&Metadata](const FString& Label,const FString& Value){Metadata->AddSlot().AutoHeight().Padding(3,4)
        [SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(Txt(Label))]
            +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text(Txt(Value))]];};
    TextInfo(TEXT("선택 에셋"),Material->GetPathName());TextInfo(TEXT("종류"),Material->GetClass()->GetName());
    FString Chain;TSet<UMaterialInterface*> Seen;
    for(UMaterialInterface* Current=Material;Current && !Seen.Contains(Current);) {
        Seen.Add(Current);if(!Chain.IsEmpty()) Chain+=TEXT(" → ");Chain+=Current->GetName();
        auto ParentInstance=Cast<UMaterialInstance>(Current);Current=ParentInstance?ParentInstance->Parent:nullptr;
    }
    TextInfo(TEXT("상속 경로"),Chain);
    if(auto Base=Material->GetMaterial()) TextInfo(TEXT("Material Domain"),UEnum::GetDisplayValueAsText(Base->MaterialDomain.GetValue()).ToString());
    AddSection(TEXT("에셋 정보 · 상속 경로"),Metadata,true);
}

void SMaterialInfoViewer::RebuildParameterGroups()
{
    ParameterGroups->ClearChildren(); GroupAreas.Empty();
    TArray<FString> Groups;
    for(auto Row:Rows) Groups.AddUnique(Row->Group);
    for(const FString& Group:Groups)
    {
        auto Body=SNew(SVerticalBox);
        const TArray<FString> Kinds={TEXT("Static Switch"),TEXT("Vector / Color"),TEXT("Scalar"),TEXT("Texture"),TEXT("Static Mask")};
        const TArray<FString> Titles={TEXT("Static Switch Parameter Values"),TEXT("Vector Parameter Values"),TEXT("Scalar Parameter Values"),TEXT("Texture Parameter Values"),TEXT("Static Component Mask Parameter Values")};
        for(int32 Kind=0;Kind<Kinds.Num();++Kind)
        {
            auto TypeBody=SNew(SVerticalBox); int32 Count=0;
            for(auto Row:Rows) if(Row->Group==Group && Row->Kind==Kinds[Kind]) {TypeBody->AddSlot().AutoHeight()[ParameterRow(Row)];++Count;}
            if(!Count) continue;
            const FString Key=TEXT("Type/")+Group+TEXT("/")+Kinds[Kind];
            auto Area=SNew(SExpandableArea).AreaTitle(Txt(Titles[Kind])).InitiallyCollapsed(Filter.IsEmpty() && ExpansionState.Contains(Key) && !ExpansionState[Key])
                .BorderImage(FEditorStyle::GetBrush("NoBorder")).HeaderPadding(FMargin(3,4)).Padding(FMargin(12,0,0,3))
                .OnAreaExpansionChanged_Lambda([this,Key](bool Expanded){if(Filter.IsEmpty()) ExpansionState.Add(Key,Expanded);})
                .BodyContent()[TypeBody];
            GroupAreas.Add(Key,Area); Body->AddSlot().AutoHeight()[Area];
        }
        const FString Key=TEXT("Group/")+Group;
        auto Area=SNew(SExpandableArea).AreaTitle(Txt(Group==TEXT("기본 그룹")?TEXT("파라미터 그룹"):Group))
            .InitiallyCollapsed(Filter.IsEmpty() && ExpansionState.Contains(Key) && !ExpansionState[Key])
            .BorderImage(FEditorStyle::GetBrush("ToolPanel.GroupBorder")).HeaderPadding(FMargin(4,5)).Padding(FMargin(4))
            .OnAreaExpansionChanged_Lambda([this,Key](bool Expanded){if(Filter.IsEmpty()) ExpansionState.Add(Key,Expanded);})
            .BodyContent()[Body];
        GroupAreas.Add(Key,Area);ParameterGroups->AddSlot().AutoHeight().Padding(0,0,0,4)[Area];
    }
}

TSharedRef<SWidget> SMaterialInfoViewer::ParameterRow(TSharedPtr<FMaterialInfoRow> Row)
{
    const FText Tooltip=Txt(Row->Name+TEXT("\n")+Row->Value+TEXT("\n")+Row->Origin+TEXT("\n")+Row->Source);
    auto Number=[](float Value)->TSharedRef<SWidget>{
        return SNew(SBox).MinDesiredWidth(60).MaxDesiredWidth(150)
            [SNew(SSpinBox<float>).Value(Value).IsEnabled(false)];
    };
    TSharedRef<SWidget> Value=SNew(STextBlock).Text(Txt(Row->Value)).AutoWrapText(true);
    if(Row->bValueValid)
    {
        if(Row->Kind==TEXT("Scalar")) Value=Number(Row->ScalarValue);
        if(Row->Kind==TEXT("Static Switch")) Value=SNew(SCheckBox).IsEnabled(false).IsChecked(Row->bSwitchValue?ECheckBoxState::Checked:ECheckBoxState::Unchecked);
        if(Row->bColor) Value=SNew(SBox).HeightOverride(20)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().FillWidth(1)[SNew(SColorBlock).Color(Row->Color).ShowBackgroundForAlpha(true).Size(FVector2D(80,20))]
            + SHorizontalBox::Slot().FillWidth(1)[SNew(SColorBlock).Color(Row->Color).IgnoreAlpha(true).Size(FVector2D(80,20))]];
        if(Row->Kind==TEXT("Texture"))
        {
            auto TextureValue=SNew(SHorizontalBox);
            if(Row->Texture) {
                auto Thumbnail=MakeShared<FAssetThumbnail>(FAssetData(Row->Texture),48,48,ThumbnailPool);
                TextureValue->AddSlot().AutoWidth().Padding(0,0,5,0)[SNew(SBox).WidthOverride(48).HeightOverride(48)[Thumbnail->MakeThumbnailWidget()]];
            }
            TextureValue->AddSlot().FillWidth(1).VAlign(VAlign_Center)[SNew(SBorder).Padding(4).BorderImage(FEditorStyle::GetBrush("ToolPanel.GroupBorder"))
                [SNew(STextBlock).AutoWrapText(true).Text(Txt(Row->Texture?Row->Texture->GetName():TEXT("없음"))).ToolTipText(Txt(Row->Value))]];
            Value=TextureValue;
        }
        if(Row->Kind==TEXT("Static Mask"))
        {
            auto Mask=SNew(SHorizontalBox);
            for(const TCHAR* Channel:{TEXT("R"),TEXT("G"),TEXT("B"),TEXT("A")}) {
                const bool Enabled=Row->Value.Contains(FString(Channel)+TEXT(" 1"));
                Mask->AddSlot().AutoWidth().Padding(0,0,5,0)[SNew(SCheckBox).IsEnabled(false).IsChecked(Enabled?ECheckBoxState::Checked:ECheckBoxState::Unchecked)[SNew(STextBlock).Text(Txt(Channel))]];
            }
            Value=Mask;
        }
    }
    auto Line=SNew(SHorizontalBox)
        + SHorizontalBox::Slot().FillWidth(.46f).VAlign(VAlign_Center)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().AutoWidth().Padding(0,0,5,0)[SNew(SCheckBox).IsEnabled(false).IsChecked(Row->bLocal?ECheckBoxState::Checked:ECheckBoxState::Unchecked).ToolTipText(Txt(TEXT("Override 상태 · 체크됨 = 직접 변경 / 체크 해제 = 상속 또는 기본값 · 조회 전용")))]
            + SHorizontalBox::Slot().FillWidth(1).VAlign(VAlign_Center)[SNew(STextBlock).Text(Txt(Row->Name)).ToolTipText(Tooltip)]]
        + SHorizontalBox::Slot().FillWidth(.54f).Padding(5,0).VAlign(VAlign_Center)[Value]
        + SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[SNew(SBox).WidthOverride(56)
            [SNew(STextBlock).Text(Txt(Row->bLocal?TEXT("직접 변경"):Row->Origin==TEXT("머티리얼 기본값")?TEXT("기본값"):Row->Source.IsEmpty()?TEXT("출처 확인"):TEXT("상속")))
                .ColorAndOpacity(Row->bLocal?FLinearColor(1,.65f,.2f):FLinearColor(.4f,.8f,1)).ToolTipText(Tooltip)]];
    TSharedRef<SWidget> Content=Line;
    if(Row->bColor && Row->bValueValid)
    {
        auto Channels=SNew(SVerticalBox);
        const TCHAR* Labels[]={TEXT("R"),TEXT("G"),TEXT("B"),TEXT("A")};
        for(int32 I=0;I<4;++I) Channels->AddSlot().AutoHeight().Padding(20,2)[SNew(SHorizontalBox)
            + SHorizontalBox::Slot().AutoWidth().Padding(0,0,10,0)[SNew(STextBlock).Text(Txt(Labels[I]))]
            + SHorizontalBox::Slot().FillWidth(1)[Number(Row->Color.Component(I))]];
        Content=SNew(SExpandableArea).InitiallyCollapsed(true).BorderImage(FEditorStyle::GetBrush("NoBorder")).HeaderPadding(FMargin(0)).Padding(FMargin(0))
            .HeaderContent()[Line].BodyContent()[Channels];
    }
    return SNew(SBorder).BorderImage(FEditorStyle::GetBrush("NoBorder")).Padding(FMargin(4,3)).ToolTipText(Tooltip)[Content];
}
