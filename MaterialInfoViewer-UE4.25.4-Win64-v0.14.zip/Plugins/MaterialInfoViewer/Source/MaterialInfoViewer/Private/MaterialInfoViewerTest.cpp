#if WITH_DEV_AUTOMATION_TESTS
#include "MaterialInfoViewer.h"
#include "MaterialInfoPreview.h"
#include "Misc/AutomationTest.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceConstant.h"
#include "Materials/MaterialExpressionScalarParameter.h"
#include "Materials/MaterialExpressionVectorParameter.h"
#include "Materials/MaterialExpressionStaticSwitchParameter.h"
#include "StaticParameterSet.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/SWindow.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Layout/SSplitter.h"
#include "EditorViewportClient.h"
#include "InputCoreTypes.h"
#include "Slate/WidgetRenderer.h"
#include "Engine/TextureRenderTarget2D.h"
#include "RenderingThread.h"
#include "ImageUtils.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Text/STextBlock.h"
#include "AssetRegistryModule.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FMaterialInfoInheritanceTest,"MaterialInfoViewer.Inheritance.ValuesAndOrigins",EAutomationTestFlags::EditorContext|EAutomationTestFlags::EngineFilter)
bool FMaterialInfoInheritanceTest::RunTest(const FString& Parameters)
{
    TStrongObjectPtr<UMaterial> Base(NewObject<UMaterial>());
    for(const TCHAR* Name:{TEXT("DefaultOnly"),TEXT("ParentValue"),TEXT("LocalValue"),TEXT("SameAsParent")}) {
        auto Expression=NewObject<UMaterialExpressionScalarParameter>(Base.Get());
        Expression->ParameterName=Name; Expression->DefaultValue=1; Expression->Group=TEXT("Test"); Expression->ExpressionGUID=FGuid::NewGuid();
        Base->Expressions.Add(Expression);
    }
    auto Color=NewObject<UMaterialExpressionVectorParameter>(Base.Get());
    Color->ParameterName=TEXT("Tint"); Color->DefaultValue=FLinearColor::White; Color->ExpressionGUID=FGuid::NewGuid(); Base->Expressions.Add(Color);
    auto Switch=NewObject<UMaterialExpressionStaticSwitchParameter>(Base.Get());
    Switch->ParameterName=TEXT("Feature"); Switch->DefaultValue=false; Switch->ExpressionGUID=FGuid::NewGuid(); Base->Expressions.Add(Switch);
    Base->UpdateCachedExpressionData();
    TStrongObjectPtr<UMaterialInstanceConstant> Parent(NewObject<UMaterialInstanceConstant>());
    Parent->SetParentEditorOnly(Base.Get(),false);
    Parent->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("ParentValue")),2);
    Parent->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("SameAsParent")),4);
    Parent->SetVectorParameterValueEditorOnly(FMaterialParameterInfo(TEXT("Tint")),FLinearColor(.2f,.4f,.8f));
    FStaticParameterSet ParentStatic;
    ParentStatic.StaticSwitchParameters.Add(FStaticSwitchParameter(FMaterialParameterInfo(TEXT("Feature")),true,true,Switch->ExpressionGUID));
    Parent->UpdateStaticPermutation(ParentStatic);
    TStrongObjectPtr<UMaterialInstanceConstant> Child(NewObject<UMaterialInstanceConstant>());
    Child->SetParentEditorOnly(Parent.Get(),false);
    Child->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("LocalValue")),3);
    Child->SetScalarParameterValueEditorOnly(FMaterialParameterInfo(TEXT("SameAsParent")),4);
    auto Rows=ReadMaterialParameters(Child.Get());
    auto Find=[&](const TCHAR* Name)->TSharedPtr<FMaterialInfoRow>{for(auto R:Rows) if(R->Name==Name) return R; return nullptr;};
    TestEqual(TEXT("All exposed parameter kinds enumerated"),Rows.Num(),6);
    auto Default=Find(TEXT("DefaultOnly")); auto Inherited=Find(TEXT("ParentValue")); auto Local=Find(TEXT("LocalValue")); auto Same=Find(TEXT("SameAsParent")); auto Tint=Find(TEXT("Tint")); auto Feature=Find(TEXT("Feature"));
    if(!Default || !Inherited || !Local || !Same || !Tint || !Feature) { AddError(TEXT("Fixture parameters missing")); return false; }
    TestEqual(TEXT("Default effective value"),Default->Value,FString(TEXT("1.0")));
    TestEqual(TEXT("Base source reached through two parents"),Default->Source,Base->GetPathName());
    TestEqual(TEXT("Inherited effective value"),Inherited->Value,FString(TEXT("2.0")));
    TestEqual(TEXT("Inherited source"),Inherited->Source,Parent->GetPathName());
    TestFalse(TEXT("Inherited is not local"),Inherited->bLocal);
    TestEqual(TEXT("Local effective value"),Local->Value,FString(TEXT("3.0")));
    TestTrue(TEXT("Local override labelled"),Local->bLocal);
    TestTrue(TEXT("Same value as parent is still an explicit override"),Same->bLocal);
    TestTrue(TEXT("Inherited vector effective value"),Tint->Color.Equals(FLinearColor(.2f,.4f,.8f)));
    TestEqual(TEXT("Inherited static switch effective value"),Feature->Value,FString(TEXT("True")));
    TestEqual(TEXT("Inherited static switch source"),Feature->Source,Parent->GetPathName());
    TestFalse(TEXT("Inherited static switch is not local"),Feature->bLocal);
    TestEqual(TEXT("Group name"),Local->Group,FString(TEXT("Test")));
    TestEqual(TEXT("Read does not change child overrides"),Child->ScalarParameterValues.Num(),2);
    FStaticParameterSet ChildStatic;
    ChildStatic.StaticSwitchParameters.Add(FStaticSwitchParameter(FMaterialParameterInfo(TEXT("Feature")),false,true,Switch->ExpressionGUID));
    Child->UpdateStaticPermutation(ChildStatic);
    for(auto Row:ReadMaterialParameters(Child.Get())) if(Row->Name==TEXT("Feature")) {
        TestEqual(TEXT("Local static switch effective value"),Row->Value,FString(TEXT("False")));
        TestTrue(TEXT("Local static switch override labelled"),Row->bLocal);
    }
    TestEqual(TEXT("Null selection is empty"),ReadMaterialParameters(nullptr).Num(),0);
    return true;
}

class FMaterialInfoWait : public IAutomationLatentCommand
{
    TFunction<bool()> Callback;
public:
    FMaterialInfoWait(TFunction<bool()> InCallback):Callback(MoveTemp(InCallback)){}
    bool Update() override {return Callback();}
};
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FMaterialInfoViewerTest,"MaterialInfoViewer.Editor.SelectionPreviewReadOnly",EAutomationTestFlags::EditorContext|EAutomationTestFlags::EngineFilter)
bool FMaterialInfoViewerTest::RunTest(const FString& Parameters)
{
    auto Material=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/AdvancedMagicFX13/Materials/MI_ky_fire03b.MI_ky_fire03b"));
    if(!TestNotNull(TEXT("Real project material"),Material)) return false;
    auto Viewer=SNew(SMaterialInfoViewer);
    const bool WasDirty=Material->GetOutermost()->IsDirty();
    Viewer->SelectAsset(FAssetData(Material));
    TestTrue(TEXT("Parameters listed"),Viewer->AllRows.Num()>0);
    TestEqual(TEXT("Preview uses selected material"),Viewer->Preview->GetMaterial(),Material);
    const int32 Total=Viewer->Rows.Num();
    Viewer->bLocalOnly=true; Viewer->FilterRows();
    for(auto R:Viewer->Rows) TestTrue(TEXT("Override-only filter"),R->bLocal);
    TestTrue(TEXT("Subset of parameters"),Viewer->Rows.Num()<=Total);
    Viewer->bLocalOnly=false; Viewer->Filter=TEXT("__no_match__");Viewer->FilterRows();
    TestEqual(TEXT("Search filters values"),Viewer->Rows.Num(),0);
    Viewer->Filter.Empty(); Viewer->FilterRows();
    TestTrue(TEXT("Parameter groups and type sections created"),Viewer->GroupAreas.Num()>=5);
    if(Viewer->GroupAreas.Num()) {
        const FString Key=Viewer->GroupAreas.CreateConstIterator().Key();
        Viewer->GroupAreas[Key]->SetExpanded(false);
        Viewer->FilterRows();
        TestFalse(TEXT("Collapsed state retained after rebuild"),Viewer->GroupAreas[Key]->IsExpanded());
        Viewer->Filter=TEXT("Scalar"); Viewer->FilterRows();
        for(const auto& Area:Viewer->GroupAreas) TestTrue(TEXT("Search reveals matching groups"),Area.Value->IsExpanded());
        Viewer->Filter.Empty();Viewer->FilterRows();
        TestFalse(TEXT("Clearing search restores collapsed state"),Viewer->GroupAreas[Key]->IsExpanded());
        Viewer->GroupAreas[Key]->SetExpanded(true);
    }
    int32 Checkboxes=0,Numbers=0,Swatches=0;
    TFunction<void(const TSharedRef<SWidget>&)> Inspect=[&](const TSharedRef<SWidget>& Widget) {
        const FString Type=Widget->GetTypeAsString();
        if(Type.Contains(TEXT("CheckBox"))) {++Checkboxes;TestFalse(TEXT("Parameter checkbox is read-only"),Widget->IsEnabled());}
        if(Type.Contains(TEXT("SpinBox"))) {++Numbers;TestFalse(TEXT("Parameter numeric field is read-only"),Widget->IsEnabled());}
        if(Type==TEXT("SColorBlock")) ++Swatches;
        auto Children=Widget->GetChildren(); for(int32 I=0;I<Children->Num();++I) Inspect(Children->GetChildAt(I));
    };
    Inspect(Viewer->ParameterGroups.ToSharedRef());
    TestTrue(TEXT("Override and switch checkboxes displayed"),Checkboxes>=Viewer->Rows.Num());
    TestTrue(TEXT("Numeric fields displayed"),Numbers>0);
    TestTrue(TEXT("Color swatches displayed"),Swatches>0);
    int32 Dropdowns=0,AssetThumbnails=0;
    TFunction<void(const TSharedRef<SWidget>&)> InspectDetails=[&](const TSharedRef<SWidget>& Widget) {
        const FString Type=Widget->GetTypeAsString();
        if(Type.Contains(TEXT("ComboButton"))) {++Dropdowns;TestFalse(TEXT("Basic info dropdown is read-only"),Widget->IsEnabled());}
        if(Type.Contains(TEXT("CheckBox")) || Type.Contains(TEXT("SpinBox"))) TestFalse(TEXT("Basic info checkbox/number is read-only"),Widget->IsEnabled());
        if(Type==TEXT("SAssetThumbnail")) ++AssetThumbnails;
        auto Children=Widget->GetChildren();for(int32 I=0;I<Children->Num();++I) InspectDetails(Children->GetChildAt(I));
    };
    InspectDetails(Viewer->Details.ToSharedRef());
    TestEqual(TEXT("Parent, physical material, blend and shading dropdowns"),Dropdowns,4);
    TestEqual(TEXT("Parent and physical material thumbnail widgets"),AssetThumbnails,2);
    auto Window=SNew(SWindow).Title(FText::FromString(TEXT("Material Info Viewer — 조회 전용"))).ClientSize(FVector2D(1500,1000))[Viewer];
    FSlateApplication::Get().AddWindow(Window);
    auto Files=MakeShared<TArray<FString>>(); IFileManager::Get().FindFilesRecursive(*Files,*FPaths::ProjectContentDir(),TEXT("*.uasset"),true,false); Files->Sort();
    auto Stage=MakeShared<int32>(0); auto Paused=MakeShared<float>(0);auto OldHeight=MakeShared<float>(0); const double Start=FPlatformTime::Seconds();
    ADD_LATENT_AUTOMATION_COMMAND(FMaterialInfoWait([this,Viewer,Window,Material,WasDirty,Files,Stage,Paused,OldHeight,Start]{
        const double Time=FPlatformTime::Seconds()-Start;
        if(*Stage==0 && Time>3) {
            TestTrue(TEXT("Preview time advances"),Viewer->Preview->GetPreviewTime()>0);
            *OldHeight=Viewer->Preview->GetCachedGeometry().GetLocalSize().Y;
            Viewer->PreviewSplitter->SlotAt(0).SizeValue=.5f;Viewer->PreviewSplitter->SlotAt(1).SizeValue=.5f;
            Viewer->Preview->TogglePause(); *Paused=Viewer->Preview->GetPreviewTime(); *Stage=1;
        }
        if(*Stage==1 && Time>4) {
            TestEqual(TEXT("Pause freezes preview world"),Viewer->Preview->GetPreviewTime(),*Paused);
            TestTrue(TEXT("Splitter resize grows actual preview viewport"),Viewer->Preview->GetCachedGeometry().GetLocalSize().Y>*OldHeight+20);
            auto Camera=Viewer->Preview->GetViewportClient();auto Viewport=Camera->Viewport;
            const auto Before=Camera->GetViewRotation();
            Camera->InputKey(Viewport,0,EKeys::LeftMouseButton,IE_Pressed);
            Camera->InputAxis(Viewport,0,EKeys::MouseX,50,.016f);Camera->InputAxis(Viewport,0,EKeys::MouseY,20,.016f);
            Camera->InputKey(Viewport,0,EKeys::LeftMouseButton,IE_Released);
            TestFalse(TEXT("Left drag rotates preview camera"),Camera->GetViewRotation().Equals(Before));
            const float BeforeZoom=Camera->GetViewLocation().Size();
            Camera->InputKey(Viewport,0,EKeys::MouseScrollUp,IE_Pressed);
            TestTrue(TEXT("Wheel zooms in"),Camera->GetViewLocation().Size()<BeforeZoom);
            Camera->InputKey(Viewport,0,EKeys::MouseScrollDown,IE_Pressed);
            TestTrue(TEXT("Wheel zooms out"),FMath::IsNearlyEqual(Camera->GetViewLocation().Size(),BeforeZoom,.1f));
            Camera->InputKey(Viewport,0,EKeys::RightMouseButton,IE_Pressed);
            Camera->InputAxis(Viewport,0,EKeys::MouseY,20,.016f);
            Camera->InputKey(Viewport,0,EKeys::RightMouseButton,IE_Released);
            TestTrue(TEXT("Right drag zooms camera"),Camera->GetViewLocation().Size()>BeforeZoom);
            Camera->InputKey(Viewport,0,EKeys::F,IE_Pressed);
            TestTrue(TEXT("F resets camera orientation"),Camera->GetViewRotation().Equals(FRotator::ZeroRotator));
            Camera->InputKey(Viewport,0,EKeys::LeftMouseButton,IE_Pressed);Camera->InputAxis(Viewport,0,EKeys::MouseX,35,.016f);Camera->InputKey(Viewport,0,EKeys::LeftMouseButton,IE_Released);
            const auto ShapeCamera=Camera->GetViewRotation();
            Viewer->Preview->TogglePause(); Viewer->Preview->ToggleShape();
            TestTrue(TEXT("Shape switch preserves view"),Camera->GetViewRotation().Equals(ShapeCamera));
            TestTrue(TEXT("Plane preview selected"),Viewer->Preview->IsPlane()); *Stage=2;
        }
        if(*Stage==2 && Time>7) {
            FWidgetRenderer Renderer(true); const FVector2D Size(1500,1000);
            TStrongObjectPtr<UTextureRenderTarget2D> Target(FWidgetRenderer::CreateTargetFor(Size,TF_Bilinear,true));
            Renderer.DrawWidget(Target.Get(),Viewer,Size,.016f);FlushRenderingCommands();
            TArray<FColor> Pixels; FReadSurfaceDataFlags Flags(RCM_UNorm);Flags.SetLinearToGamma(false);
            if(Target->GameThread_GetRenderTargetResource()->ReadPixels(Pixels,Flags)) {
                TArray<uint8> Png; FImageUtils::CompressImageArray(1500,1000,Pixels,Png);
                FFileHelper::SaveArrayToFile(Png,*(FPaths::ProjectSavedDir()/TEXT("CascadeAssembly/material-info-viewer.png")));
            }
            Viewer->Refresh(); TestEqual(TEXT("Viewing does not dirty material"),Material->GetOutermost()->IsDirty(),WasDirty);
            CollectGarbage(RF_NoFlags); TestEqual(TEXT("Selected material retained through GC"),Viewer->Preview->GetMaterial(),Material);
            Viewer->SelectAsset(FAssetData()); TestEqual(TEXT("Selection clear resets parameters"),Viewer->Rows.Num(),0);
            TestNull(TEXT("Selection clear resets preview"),Viewer->Preview->GetMaterial());
            TArray<FString> After;IFileManager::Get().FindFilesRecursive(After,*FPaths::ProjectContentDir(),TEXT("*.uasset"),true,false);After.Sort();
            TestTrue(TEXT("Viewer creates no assets"),After==*Files);
            Window->RequestDestroyWindow(); return true;
        }
        return false;
    }));
    return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FMaterialBlendFilterTest,"MaterialInfoViewer.Filter.BlendAndSearch",EAutomationTestFlags::EditorContext|EAutomationTestFlags::EngineFilter)
bool FMaterialBlendFilterTest::RunTest(const FString& Parameters)
{
    auto Viewer=SNew(SMaterialInfoViewer);
    const EBlendMode Modes[]={BLEND_Opaque,BLEND_Masked,BLEND_Translucent,BLEND_Additive};
    for(int32 Mode=0;Mode<4;++Mode) {
        TStrongObjectPtr<UMaterial> Base(NewObject<UMaterial>());Base->BlendMode=Modes[Mode];
        TStrongObjectPtr<UMaterialInstanceConstant> Parent(NewObject<UMaterialInstanceConstant>());
        Parent->SetParentEditorOnly(Base.Get(),false);Parent->UpdateOverridableBaseProperties();
        TStrongObjectPtr<UMaterialInstanceConstant> Child(NewObject<UMaterialInstanceConstant>());
        Child->SetParentEditorOnly(Parent.Get(),false);Child->UpdateOverridableBaseProperties();
        for(int32 Filter=1;Filter<=4;++Filter) {
            Viewer->bAllBlendModes=false;Viewer->BlendMask=1<<(Filter-1);
            TestEqual(TEXT("Base material classified by final blend"),!Viewer->ShouldFilterMaterial(FAssetData(Base.Get())),Filter==Mode+1);
            TestEqual(TEXT("Two-level inherited instance classified by final blend"),!Viewer->ShouldFilterMaterial(FAssetData(Child.Get())),Filter==Mode+1);
        }
        Viewer->BlendMask=3;
        TestEqual(TEXT("Opaque and Masked union accepts either inherited mode"),!Viewer->ShouldFilterMaterial(FAssetData(Child.Get())),Mode<2);
        Viewer->BlendMask=0;TestTrue(TEXT("Empty selection excludes all modes"),Viewer->ShouldFilterMaterial(FAssetData(Child.Get())));
        Parent->BasePropertyOverrides.bOverride_BlendMode=true;Parent->BasePropertyOverrides.BlendMode=BLEND_Additive;
        Parent->UpdateOverridableBaseProperties();Child->UpdateOverridableBaseProperties();Viewer->bAllBlendModes=false;Viewer->BlendMask=8;
        TestFalse(TEXT("Parent override inherited as Additive"),Viewer->ShouldFilterMaterial(FAssetData(Child.Get())));
        Child->BasePropertyOverrides.bOverride_BlendMode=true;Child->BasePropertyOverrides.BlendMode=BLEND_Masked;
        Child->UpdateOverridableBaseProperties();Viewer->bAllBlendModes=false;Viewer->BlendMask=2;
        TestFalse(TEXT("Local override wins over parent"),Viewer->ShouldFilterMaterial(FAssetData(Child.Get())));
        Viewer->bAllBlendModes=false;Viewer->BlendMask=8;TestTrue(TEXT("Old parent blend excluded after local override"),Viewer->ShouldFilterMaterial(FAssetData(Child.Get())));
    }
    Viewer->bAllBlendModes=true;Viewer->BlendMask=0;
    TSharedPtr<SSearchBox> Search;
    TFunction<void(const TSharedRef<SWidget>&)> Find=[&](const TSharedRef<SWidget>& Widget){
        const FString Type=Widget->GetTypeAsString();
        if(Type==TEXT("SSearchBox") && !Search.IsValid()) Search=StaticCastSharedRef<SSearchBox>(Widget);
        auto Children=Widget->GetChildren();for(int32 I=0;I<Children->Num();++I) Find(Children->GetChildAt(I));
    };
    Find(Viewer->AssetPicker.ToSharedRef());
    if(!TestTrue(TEXT("Native picker search found"),Search.IsValid())) return false;
    TFunction<int32()> Count=[Viewer]{
        int32 Result=-1;
        TFunction<void(const TSharedRef<SWidget>&)> Visit=[&](const TSharedRef<SWidget>& Widget){
            if(Widget->GetTypeAsString()==TEXT("STextBlock")) {
                const FString Text=StaticCastSharedRef<STextBlock>(Widget)->GetText().ToString();
                if(Text.Len() && FChar::IsDigit(Text[0]) && (Text.Contains(TEXT("항목")) || Text.Contains(TEXT("item")))) Result=FCString::Atoi(*Text.Replace(TEXT(","),TEXT("")));
            }
            auto Children=Widget->GetChildren();for(int32 I=0;I<Children->Num();++I) Visit(Children->GetChildAt(I));
        };
        Visit(Viewer->AssetPicker.ToSharedRef());return Result;
    };
    auto& Registry=FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));Registry.Get().SearchAllAssets(true);
    FARFilter AssetFilter;AssetFilter.ClassNames.Add(UMaterialInterface::StaticClass()->GetFName());AssetFilter.bRecursiveClasses=true;AssetFilter.PackagePaths.Add(TEXT("/Game"));AssetFilter.bRecursivePaths=true;
    TArray<FAssetData> Assets;Registry.Get().GetAssets(AssetFilter,Assets);
    auto ExpectedCounts=MakeShared<TArray<int32>>(TArray<int32>{Assets.Num(),0,0,0,0});
    auto WallCounts=MakeShared<TArray<int32>>(TArray<int32>{0,0,0,0,0});
    auto FireCounts=MakeShared<TArray<int32>>(TArray<int32>{0,0,0,0,0});
    auto MICounts=MakeShared<TArray<int32>>(TArray<int32>{0,0,0,0,0});
    int32 ExpectedSearch=0,ExpectedOpaque=0;
    for(auto Asset:Assets) {
        auto Material=Cast<UMaterialInterface>(Asset.GetAsset());
        for(auto Pair:{TPair<FString,TSharedPtr<TArray<int32>>>(TEXT("MI_DemoWall"),WallCounts),TPair<FString,TSharedPtr<TArray<int32>>>(TEXT("MI_ky_fire03b"),FireCounts),TPair<FString,TSharedPtr<TArray<int32>>>(TEXT("MI_"),MICounts)})
            if(Asset.AssetName.ToString().Contains(Pair.Key)) {++(*Pair.Value)[0];if(Material) for(int32 I=0;I<4;++I) if(Material->GetBlendMode()==Modes[I]) ++(*Pair.Value)[I+1];}
        if(Material) for(int32 I=0;I<4;++I) if(Material->GetBlendMode()==Modes[I]) ++(*ExpectedCounts)[I+1];
        if(Asset.AssetName.ToString().Contains(TEXT("MI_DemoWall"))) {++ExpectedSearch;if(Material && Material->GetBlendMode()==BLEND_Opaque) ++ExpectedOpaque;}
    }
    auto Window=SNew(SWindow).Title(FText::FromString(TEXT("Material Info Viewer — Blend Mode 필터"))).ClientSize(FVector2D(1500,1000))[Viewer];
    FSlateApplication::Get().AddWindow(Window);
    auto Stage=MakeShared<int32>(0);auto Last=MakeShared<double>(FPlatformTime::Seconds());
    ADD_LATENT_AUTOMATION_COMMAND(FMaterialInfoWait([this,Viewer,Window,Search,Count,ExpectedSearch,ExpectedOpaque,ExpectedCounts,WallCounts,FireCounts,MICounts,Stage,Last]{
        const double Wait=FPlatformTime::Seconds()-*Last;
        if(Wait<2) return false;
        if(Wait<60 && Viewer->bBlendCounting) return false;
        if(Wait<30 && ((*Stage==1 && Count()!=ExpectedOpaque) || (*Stage==2 && Count()!=ExpectedSearch) || (*Stage==3 && Count()<=0))) return false;
        if(Wait<30 && ((*Stage==8 && Count()!=(*MICounts)[1]+(*MICounts)[2]) || (*Stage==9 && Count()!=(*MICounts)[2]) || (*Stage==10 && Count()!=0) || (*Stage==11 && Count()!=(*MICounts)[0]))) return false;
        *Last=FPlatformTime::Seconds();
        if(*Stage==0) {
            TestFalse(TEXT("Blend count finished"),Viewer->bBlendCounting);
            TestTrue(TEXT("All five counts match project material inventory"),Viewer->BlendCounts==*ExpectedCounts);
            for(int32 I=0;I<5;++I) TestTrue(TEXT("Dropdown label includes exact count"),Viewer->BlendLabel(I).ToString().Contains(FString::Printf(TEXT("(%d개)"),(*ExpectedCounts)[I])));
            Search->SetText(FText::FromString(TEXT("MI_DemoWall")));Viewer->ApplyBlendSelection(1,false);
            TestEqual(TEXT("Blend change preserves native name search"),Search->GetText().ToString(),FString(TEXT("MI_DemoWall")));*Stage=1;return false;
        }
        if(*Stage==1) {
            TestTrue(TEXT("Name search updates all mode counts to wall matches"),Viewer->BlendCounts==*WallCounts);
            TestEqual(TEXT("Actual picker combines Opaque with name search"),Count(),ExpectedOpaque);
            Viewer->ApplyBlendSelection(0,true);*Stage=2;return false;
        }
        if(*Stage==2) {
            TestEqual(TEXT("All restores previously excluded search matches"),Count(),ExpectedSearch);
            Search->SetText(FText::FromString(TEXT("MI_ky_fire03b")));Viewer->ApplyBlendSelection(4,false);*Stage=3;return false;
        }
        if(*Stage==3) {
            TestTrue(TEXT("Changing blend does not limit other search mode counts"),Viewer->BlendCounts==*FireCounts);
            TestTrue(TEXT("Actual Translucent and search result exists"),Count()>0);
            auto Material=LoadObject<UMaterialInterface>(nullptr,TEXT("/Game/AdvancedMagicFX13/Materials/MI_ky_fire03b.MI_ky_fire03b"));
            Viewer->SelectAsset(FAssetData(Material));*Stage=4;return false;
        }
        if(*Stage==5) {
            TestTrue(TEXT("Recount keeps current search scope without accumulating"),Viewer->BlendCounts==*FireCounts);
            TestNull(TEXT("Source refresh does not restore excluded selection"),Viewer->Selected.Get());
            TestNull(TEXT("Source refresh keeps excluded preview empty"),Viewer->Preview->GetMaterial());
            Search->SetText(FText::FromString(TEXT("__no_material_match__")));*Stage=6;return false;
        }
        if(*Stage==6) {
            TestTrue(TEXT("No search matches yields zero for every blend"),Viewer->BlendCounts==TArray<int32>({0,0,0,0,0}));
            TestEqual(TEXT("No matching visible items"),Count(),0);
            Search->SetText(FText::GetEmpty());*Stage=7;return false;
        }
        if(*Stage==7) {
            TestTrue(TEXT("Clearing search restores project-wide mode counts"),Viewer->BlendCounts==*ExpectedCounts);
            TestEqual(TEXT("Clearing search retains active Opaque filter"),Count(),(*ExpectedCounts)[1]);
            Search->SetText(FText::FromString(TEXT("MI_")));
            Viewer->SetBlendChecked(2,ECheckBoxState::Checked);*Stage=8;return false;
        }
        if(*Stage==8) {
            TestEqual(TEXT("Native picker shows Opaque OR Masked with name search"),Count(),(*MICounts)[1]+(*MICounts)[2]);
            TestTrue(TEXT("Multiple selections keep counts for all matching kinds"),Viewer->BlendCounts==*MICounts);
            FWidgetRenderer Renderer(true);const FVector2D Size(1500,1000);
            TStrongObjectPtr<UTextureRenderTarget2D> Target(FWidgetRenderer::CreateTargetFor(Size,TF_Bilinear,true));Renderer.DrawWidget(Target.Get(),Viewer,Size,.016f);FlushRenderingCommands();
            TArray<FColor> Pixels;FReadSurfaceDataFlags Flags(RCM_UNorm);Flags.SetLinearToGamma(false);
            if(Target->GameThread_GetRenderTargetResource()->ReadPixels(Pixels,Flags)) {
                TArray<uint8> Png;FImageUtils::CompressImageArray(1500,1000,Pixels,Png);FFileHelper::SaveArrayToFile(Png,*(FPaths::ProjectSavedDir()/TEXT("CascadeAssembly/material-blend-multi.png")));
            }
            Viewer->SetBlendChecked(1,ECheckBoxState::Unchecked);*Stage=9;return false;
        }
        if(*Stage==9) {
            TestEqual(TEXT("Unchecking Opaque leaves Masked search matches"),Count(),(*MICounts)[2]);
            Viewer->SetBlendChecked(2,ECheckBoxState::Unchecked);*Stage=10;return false;
        }
        if(*Stage==10) {
            TestEqual(TEXT("No checked kinds makes picker empty"),Count(),0);
            Viewer->SetBlendChecked(0,ECheckBoxState::Checked);*Stage=11;return false;
        }
        if(*Stage==11) {
            TestEqual(TEXT("All restores search matches across every mode"),Count(),(*MICounts)[0]);
            TestEqual(TEXT("Name search survives multi-selection changes"),Search->GetText().ToString(),FString(TEXT("MI_")));
            Window->RequestDestroyWindow();return true;
        }
        FWidgetRenderer Renderer(true);const FVector2D Size(1500,1000);
        TStrongObjectPtr<UTextureRenderTarget2D> Target(FWidgetRenderer::CreateTargetFor(Size,TF_Bilinear,true));Renderer.DrawWidget(Target.Get(),Viewer,Size,.016f);FlushRenderingCommands();
        TArray<FColor> Pixels;FReadSurfaceDataFlags Flags(RCM_UNorm);Flags.SetLinearToGamma(false);
        if(Target->GameThread_GetRenderTargetResource()->ReadPixels(Pixels,Flags)) {
            TArray<uint8> Png;FImageUtils::CompressImageArray(1500,1000,Pixels,Png);FFileHelper::SaveArrayToFile(Png,*(FPaths::ProjectSavedDir()/TEXT("CascadeAssembly/material-blend-filter.png")));
        }
        Viewer->ApplyBlendSelection(1,false);
        TestNull(TEXT("Selection outside new blend cleared"),Viewer->Selected.Get());
        TestNull(TEXT("Preview outside new blend cleared"),Viewer->Preview->GetMaterial());
        Viewer->RequestBlendCount();
        *Stage=5;return false;
    }));
    return true;
}
#endif
