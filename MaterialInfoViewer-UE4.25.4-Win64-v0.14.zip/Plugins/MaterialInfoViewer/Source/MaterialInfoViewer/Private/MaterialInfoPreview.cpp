#include "MaterialInfoPreview.h"
#include "EditorViewportClient.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "UnrealClient.h"
#include "InputCoreTypes.h"

class FMaterialInfoViewportClient : public FEditorViewportClient
{
    bool bRotate=false,bZoom=false;
    float Yaw=0,Pitch=0,Distance=220,Aspect=2;
    void ApplyCamera()
    {
        const FRotator Rotation(Pitch,Yaw,0);
        SetViewRotation(Rotation);
        SetViewLocation(-Rotation.Vector()*Distance*FMath::Max(1.f,Aspect/2.f));
        Invalidate();
    }
public:
    FMaterialInfoViewportClient(FPreviewScene* Scene,const TSharedRef<SEditorViewport>& Widget)
        : FEditorViewportClient(nullptr,Scene,Widget) {}
    // Material Time nodes must use this preview world's time so pause also freezes shaders.
    virtual bool UseAppTime() const override { return false; }
    void SetAspect(float Value) {if(!FMath::IsNearlyEqual(Aspect,Value,.001f)){Aspect=Value;ApplyCamera();}}
    void ResetCamera() {Yaw=0;Pitch=0;Distance=220;ApplyCamera();}
    virtual bool InputKey(FViewport* InViewport,int32 ControllerId,FKey Key,EInputEvent Event,float Amount=1.f,bool Gamepad=false) override
    {
        if(Key==EKeys::LeftMouseButton || Key==EKeys::RightMouseButton) {
            (Key==EKeys::LeftMouseButton?bRotate:bZoom)=Event!=IE_Released;
            return true;
        }
        if(Event==IE_Pressed && (Key==EKeys::MouseScrollUp || Key==EKeys::MouseScrollDown)) {
            Distance=FMath::Clamp(Distance*(Key==EKeys::MouseScrollUp?.85f:1.f/.85f),60.f,2000.f);ApplyCamera();return true;
        }
        if(Key==EKeys::F && Event==IE_Pressed) {ResetCamera();return true;}
        return FEditorViewportClient::InputKey(InViewport,ControllerId,Key,Event,Amount,Gamepad);
    }
    virtual bool InputAxis(FViewport* InViewport,int32 ControllerId,FKey Key,float Delta,float DeltaTime,int32 Samples=1,bool Gamepad=false) override
    {
        if(Key==EKeys::MouseX || Key==EKeys::MouseY) {
            if(bRotate) {
                if(Key==EKeys::MouseX) Yaw=FMath::UnwindDegrees(Yaw+Delta*.5f);
                else Pitch=FMath::Clamp(Pitch+Delta*.5f,-85.f,85.f);
                ApplyCamera();return true;
            }
            if(bZoom && Key==EKeys::MouseY) {Distance=FMath::Clamp(Distance*FMath::Exp(Delta*.01f),60.f,2000.f);ApplyCamera();return true;}
        }
        return FEditorViewportClient::InputAxis(InViewport,ControllerId,Key,Delta,DeltaTime,Samples,Gamepad);
    }
    virtual void LostFocus(FViewport* InViewport) override {bRotate=false;bZoom=false;FEditorViewportClient::LostFocus(InViewport);}
};

void SMaterialInfoPreview::Construct(const FArguments& Args)
{
    Mesh = NewObject<UStaticMeshComponent>();
    Mesh->SetStaticMesh(LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Sphere.Sphere")));
    Scene.AddComponent(Mesh,FTransform::Identity);
    SEditorViewport::Construct(SEditorViewport::FArguments());
}
SMaterialInfoPreview::~SMaterialInfoPreview()
{
    Mesh->SetMaterial(0,nullptr);
    Scene.RemoveComponent(Mesh);
    if(Client.IsValid()) Client->Viewport=nullptr;
    Client.Reset();
}
TSharedRef<FEditorViewportClient> SMaterialInfoPreview::MakeEditorViewportClient()
{
    auto Result=MakeShared<FMaterialInfoViewportClient>(&Scene,SharedThis(this));
    Result->SetRealtime(true);
    Result->SetViewMode(VMI_Lit);
    Result->EngineShowFlags=FEngineShowFlags(ESFIM_Game);
    Result->EngineShowFlags.SetGrid(false);
    Result->EngineShowFlags.DisableAdvancedFeatures();
    Result->SetViewLocation(FVector(-220,0,0));
    Result->SetViewRotation(FRotator::ZeroRotator);
    return Result;
}
void SMaterialInfoPreview::SetMaterial(UMaterialInterface* InMaterial)
{
    Material.Reset(InMaterial);
    Mesh->SetMaterial(0,InMaterial);
    Mesh->SetVisibility(InMaterial!=nullptr);
    Invalidate();
}
void SMaterialInfoPreview::ToggleShape()
{
    bPlane=!bPlane;
    Mesh->SetStaticMesh(LoadObject<UStaticMesh>(nullptr,bPlane ? TEXT("/Engine/BasicShapes/Plane.Plane") : TEXT("/Engine/BasicShapes/Sphere.Sphere")));
    Mesh->SetRelativeRotation(bPlane ? FRotator(-90,0,0) : FRotator::ZeroRotator);
    // Plane's +Z normal faces the camera on -X.
    Mesh->SetMaterial(0,Material.Get());
    Invalidate();
}
void SMaterialInfoPreview::ResetCamera() {StaticCastSharedPtr<FMaterialInfoViewportClient>(Client)->ResetCamera();}
void SMaterialInfoPreview::Tick(const FGeometry& Geometry,double CurrentTime,float DeltaTime)
{
    SEditorViewport::Tick(Geometry,CurrentTime,DeltaTime);
    const FVector2D Size=Geometry.GetLocalSize();
    if(Size.Y>0) StaticCastSharedPtr<FMaterialInfoViewportClient>(Client)->SetAspect(Size.X/Size.Y);
    if(Material.IsValid() && !bPaused)
    {
        const float Step=FMath::Min(DeltaTime,.1f);
        Scene.GetWorld()->Tick(LEVELTICK_All,Step);
        PreviewTime+=Step;
        Invalidate();
    }
}
