#pragma once
#include "SEditorViewport.h"
#include "PreviewScene.h"
#include "UObject/StrongObjectPtr.h"
#include "Materials/MaterialInterface.h"

class SMaterialInfoPreview : public SEditorViewport
{
public:
    SLATE_BEGIN_ARGS(SMaterialInfoPreview) {} SLATE_END_ARGS()
    void Construct(const FArguments& Args);
    ~SMaterialInfoPreview();
    void SetMaterial(UMaterialInterface* InMaterial);
    void ToggleShape();
    void ResetCamera();
    void TogglePause() { bPaused = !bPaused; }
    bool IsPaused() const { return bPaused; }
    bool IsPlane() const { return bPlane; }
    float GetPreviewTime() const { return PreviewTime; }
    UMaterialInterface* GetMaterial() const { return Material.Get(); }
    virtual void Tick(const FGeometry& Geometry, double CurrentTime, float DeltaTime) override;
protected:
    virtual TSharedRef<FEditorViewportClient> MakeEditorViewportClient() override;
    virtual TSharedPtr<SWidget> MakeViewportToolbar() override { return nullptr; }
private:
    FPreviewScene Scene;
    class UStaticMeshComponent* Mesh = nullptr;
    TStrongObjectPtr<UMaterialInterface> Material;
    bool bPlane = false, bPaused = false;
    float PreviewTime = 0;
};
