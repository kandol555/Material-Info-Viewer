﻿#include "Modules/ModuleManager.h"
#include "Framework/Docking/TabManager.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Widgets/Docking/SDockTab.h"
#include "LevelEditor.h"
#include "MaterialInfoViewer.h"
#include "HAL/IConsoleManager.h"
#include "Misc/CommandLine.h"
static const FName MaterialInfoTab(TEXT("MaterialInfoViewer"));
class FMaterialInfoViewerModule : public IModuleInterface
{
    TSharedPtr<FExtender> Menu;
    TUniquePtr<FAutoConsoleCommand> OpenMaterialInfo;
public:
    virtual void StartupModule() override
    {
        if (IsRunningCommandlet()) return;
        FGlobalTabmanager::Get()->RegisterNomadTabSpawner(MaterialInfoTab,FOnSpawnTab::CreateLambda([](const FSpawnTabArgs&) {
            return SNew(SDockTab).TabRole(ETabRole::NomadTab)[SNew(SMaterialInfoViewer)];
        })).SetDisplayName(FText::FromString(TEXT("Material Info Viewer"))).SetMenuType(ETabSpawnerMenuType::Hidden);
        OpenMaterialInfo=MakeUnique<FAutoConsoleCommand>(TEXT("MaterialInfoViewer.Open"),TEXT("Open the read-only material inspector."),FConsoleCommandDelegate::CreateLambda([] {
            auto Tab=FGlobalTabmanager::Get()->InvokeTab(MaterialInfoTab);
            FString Asset;
            if(FParse::Value(FCommandLine::Get(),TEXT("MaterialInfoAsset="),Asset))
                if(auto Material=LoadObject<UMaterialInterface>(nullptr,*Asset)) StaticCastSharedRef<SMaterialInfoViewer>(Tab->GetContent())->SelectAsset(FAssetData(Material));
        }));
        Menu = MakeShared<FExtender>();
        Menu->AddMenuExtension(TEXT("WindowLayout"), EExtensionHook::After, nullptr, FMenuExtensionDelegate::CreateLambda([](FMenuBuilder& Builder) {
            Builder.AddMenuEntry(FText::FromString(TEXT("Material Info Viewer · 머티리얼 정보")), FText::FromString(TEXT("Read-only material parameters, inheritance and preview.")), FSlateIcon(),
                FUIAction(FExecuteAction::CreateLambda([] { FGlobalTabmanager::Get()->InvokeTab(MaterialInfoTab); })));
        }));
        FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetMenuExtensibilityManager()->AddExtender(Menu);
    }
    virtual void ShutdownModule() override
    {
        OpenMaterialInfo.Reset();
        if (Menu.IsValid() && FModuleManager::Get().IsModuleLoaded(TEXT("LevelEditor")))
            FModuleManager::GetModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetMenuExtensibilityManager()->RemoveExtender(Menu);
        if (!IsRunningCommandlet()) FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(MaterialInfoTab);
    }
};
IMPLEMENT_MODULE(FMaterialInfoViewerModule, MaterialInfoViewer)
