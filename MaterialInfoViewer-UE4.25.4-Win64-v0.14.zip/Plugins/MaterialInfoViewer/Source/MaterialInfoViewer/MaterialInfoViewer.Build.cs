﻿using UnrealBuildTool;
public class MaterialInfoViewer : ModuleRules
{
    public MaterialInfoViewer(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateDependencyModuleNames.AddRange(new string[] {
            "Core", "CoreUObject", "Engine", "UnrealEd", "AssetRegistry", "Json",
            "Slate", "SlateCore", "ContentBrowser", "LevelEditor", "InputCore", "EditorStyle", "AppFramework",
            "UMG", "RenderCore", "RHI"
        });
    }
}
